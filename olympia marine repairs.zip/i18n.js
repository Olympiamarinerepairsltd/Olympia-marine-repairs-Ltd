const i18n = {
  current: 'el',
  defaultsText: {},
  defaultsPlaceholder: {},
 dict: {
  el: {
      'meta.title_contact':'Olympia Marine Repairs Ltd | Επικοινωνία',
      'nav.home':'Κεντρική',
      'nav.about':'Ποιοι είμαστε',
      'nav.services':'Υπηρεσίες',
      'nav.newsletter':'Newsletter',
      'nav.contact':'Επικοινωνία',
      'site.tagline':'Η τεχνογνωσία μας. Η ασφάλειά σας σε κάθε θάλασσα.',

      'contact.hero.kicker':'Άμεση επικοινωνία',
      'contact.title':'Επικοινωνία',
      'contact.lead':'Επικοινωνήστε απευθείας με την Olympia Marine Repairs Ltd για αιτήματα προσφοράς, τεχνικό συντονισμό, voyage attendance, drydock support και επείγουσες ανάγκες. Για την πιο άμεση ανταπόκριση χρησιμοποιήστε τηλέφωνο, WhatsApp ή Viber.',

      'contact.alert.title':'Ταχύτερο κανάλι επικοινωνίας:',
      'contact.alert.text':'Για επείγοντα λειτουργικά θέματα, χρησιμοποιήστε πρώτα τηλέφωνο, WhatsApp ή Viber και έπειτα στείλτε τα στοιχεία του project μέσω της φόρμας για οργανωμένη συνέχεια.'

     
    },

  en: { ... }
}
      'about.edge.card1.text':'Leadership by engineers with strong engine-room, sea service and repair backgrounds, so decisions are made with real knowledge of onboard operating conditions.',
      'about.edge.card1.title':'Technical leadership',
      'about.edge.card2.text':'Our team can support engine-room works, electrical jobs, deck tasks, steel works and support functions under one coordinated project structure.',
      'about.edge.card2.title':'Whole-ship coverage',
      'about.edge.card3.text':'We focus on correct documentation, progress tracking, schedule discipline and delay and cost reduction whenever operationally feasible.',
      'about.edge.card3.title':'Quality-minded project control',
      'about.edge.card4.text':'From Piraeus to international partnerships, we build trust with operators, technical managers and project stakeholders who expect responsible execution and immediate response.',
      'about.edge.card4.title':'International work ethic',
      'about.edge.kicker':'The Olympia edge',
      'about.edge.title':'How we work in practice.',
      'about.hero.kicker':'About Olympia',
      'about.lead':'Olympia Marine Repairs Ltd is a Piraeus-based technical team built on real sea-going and repair experience, focused on reliability, coordination and immediate support for demanding marine projects.',
      'about.quality.kicker':'Quality statement',
      'about.statement.kicker':'Quality statement',
      'about.statement.text':'At Olympia Marine Repairs Ltd, we do not simply carry out a job. Our aim is to turn every technical challenge into an organized operational result, with responsibility, documentation and respect for the continuity of our clients’ shipping activities.',
      'about.statement.title':'Our commitment to quality.',
      'about.story.kicker':'Story',
      'about.story.p1':'Our team began to organize in August 2025 and reached its final shape in November of the same year. The core of Olympia Marine Repairs Ltd was created to combine engine-room, shipyard, deck, electrical and project coordination experience within one operational structure.',
      'about.story.p2':'Our goal is to operate as a technical partner with clear communication, disciplined organization and practical solutions for commercial, passenger, government, specialized and private vessel projects, coordinated from Piraeus with an international outlook.',
      'about.story.title':'Built on hands-on marine and repair experience.',
      'about.team.card1.meta':'11.5 years of experience',
      'about.team.card1.text':'11.5 years of experience, including 7.5 years at sea and 4 years in repairs. Responsible for leadership, team coordination, project coordination and primary client communication on technical or operational matters. Can support any task except specialized electrical works.',
      'about.team.card1.title':'Chief Engineer – Team Leader',
      'about.team.card2.meta':'46 years of experience',
      'about.team.card2.text':'46 years of experience, including 26 years in repairs and 20 years as ship crew. Contributes to overall operational control, technical work coordination and communication with the client company. Can undertake any task except specialized electrical works.',
      'about.team.card2.title':'Second Engineer – Deputy Team Leader',
      'about.team.card3.meta':'50 χρόνια εμπειρίας',
      'about.team.card3.text':'50 χρόνια εμπειρίας, με 30 χρόνια σε μηχανουργείο Περάματος/Πειραιά και επισκευές πλοίων και 20 χρόνια ως πλήρωμα. Διαθέτει εμπειρία Α΄ Μηχανικού, ισχυρή πρακτική γνώση λύσεων στο πλοίο και εκτελεί εργασίες μηχανουργείου και γενικές τεχνικές αποκαταστάσεις σε συνεννόηση με τους επικεφαλής.',
      'about.team.card3.title':'Μηχανολόγος / Μηχανουργός',
      'about.team.card4.meta':'10 years of experience',
      'about.team.card4.text':'10 years of experience with academic background, focused on ship electrical installations, troubleshooting, inspections and support for electrical and automation systems.',
      'about.team.card4.title':'Electrician',
      'about.team.card5.meta':'30 years at sea',
      'about.team.card5.text':'30 years of experience as crew. Supports deck works, deck coordination and practical onboard interventions in cooperation with the team leaders.',
      'about.team.card5.title':'Boatswain (Bosun)',
      'about.team.card6.meta':'10 years of experience',
      'about.team.card6.text':'10 years of experience, including 5 years in shipyards and 5 years onboard. Handles welding, steel works, steel renewals and other field interventions requiring applied hands-on execution.',
      'about.team.card6.title':'Fitter / Welding & Steel Works',
      'about.team.card7.meta':'Support technical staff',
      'about.team.card7.text':'The team is further supported by 3 assistant engineers and 1 assistant electrician with newer experience, helping with daily technical tasks, preparation, tool organization and supporting functions.',
      'about.team.card7.title':'Assistant Engineers & Electrical Support',
      'about.team.card8.meta':'30 years of experience',
      'about.team.card8.text':'30 years of experience, including 18 years at sea and 12 years ashore. Supports our team during demanding projects and, upon request, can also provide additional catering support for crew or passengers under a separate commercial arrangement.',
      'about.team.card8.title':'Cook / Welfare Support',
      'about.team.kicker':'Leadership & team',
      'about.team.text':'Our structure is built around leadership with sea-going and repair experience and is supported by technical personnel covering engine-room works, electrical systems, deck works, welding and support functions.',
      'about.team.title':'The team behind Olympia Marine Repairs Ltd.',
      'about.title':'About Us',
      'about.values.card1.text':'At sea there is no room for half-measures. We approach every job with seriousness, durability, technical consistency and respect for international maritime practices as well as class and inspection expectations.',
      'about.values.card1.title':'Technical Integrity',
      'about.values.card2.text':'Shipping never stops. We maintain a mindset of immediate mobilization, 24/7 responsiveness and the ability to support projects with scalable technical staffing, according to operational needs and prior coordination.',
      'about.values.card2.title':'Operational Readiness',
      'about.values.card3.text':'We work with technical reports, before-and-after photo documentation, measurements, progress reporting and clear updates so the client has a real picture of the project at every stage.',
      'about.values.card3.title':'Transparency & Accountability',
      'about.values.card4.text':'We understand that our work directly affects vessel reliability and the reputation of the managing company. That is why we emphasize discipline, proper crew presentation and professional cooperation.',
      'about.values.card4.title':'Reputation Protection',
      'about.values.kicker':'Core values',
      'about.values.title':'The principles that guide our work.',
      'about.vision.kicker':'Vision',
      'about.vision.text':'To become one of the most trusted technical partners in international shipping by combining the traditional maritime experience of Piraeus with modern engineering, technical documentation and project management methods.',
      'about.vision.title':'Our vision',
      'contact.alert.text':'For urgent operational matters, use phone, WhatsApp or Viber first, then send project details through the contact form for organized follow-up.',
      'contact.alert.title':'Fastest response channel:',
      'contact.form.company':'Company',
      'contact.form.company_ph':'Shipping company / operator',
      'contact.form.email':'Email',
      'contact.form.email_ph':'name@company.com',
      'contact.form.message':'Message',
      'contact.form.message_ph':'Please describe vessel type, port or location, required works, timing and urgency.',
      'contact.form.name':'Full name',
      'contact.form.name_ph':'Full name',
      'contact.form.phone':'Phone / WhatsApp / Viber',
      'contact.form.phone_ph':'+30 ...',
      'contact.form.service':'Service needed',
      'contact.form.service_ph':'Voyage repairs / drydock / troubleshooting / inspection support',
      'contact.form.submit':'Send request',
      'contact.forminfo.kicker':'Contact form',
      'contact.forminfo.li1':'Company and contact details',
      'contact.forminfo.li2':'Vessel or project type',
      'contact.forminfo.li3':'Port, voyage or drydock context',
      'contact.forminfo.li4':'Short technical description and urgency level',
      'contact.forminfo.note':'For truly urgent cases, call or message first and then use the form for the written technical brief.',
      'contact.forminfo.text':'The form is ideal for scope requests, quotation inquiries, drydock planning, technical descriptions and the first collection of project details.',
      'contact.forminfo.title':'Send your request in a structured way.',
      'contact.hero.kicker':'Direct communication',
      'contact.lead':'Contact Olympia Marine Repairs Ltd directly for quotation requests, technical coordination, voyage attendance, drydock support and urgent requirements. For the fastest response, use phone, WhatsApp or Viber.',
      'contact.methods.card1.meta':'Email',
      'contact.methods.card1.text':'Use email for quotations, detailed scopes, drydock planning, attachments and technical communication.',
      'contact.methods.card1.title':'Direct email coordination',
      'contact.methods.card2.meta':'Phone • WhatsApp • Viber',
      'contact.methods.card2.text':'Both direct lines belong to the team leaders responsible for coordination and closing projects.',
      'contact.methods.card2.title':'Immediate operational contact',
      'contact.methods.card3.location':'Piraeus, Greece',
      'contact.methods.card3.meta':'Location',
      'contact.methods.card3.text':'The company currently coordinates its operations from Piraeus, with direct communication for attendance, mobilization and project planning.',
      'contact.methods.card3.title':'Operational base',
      'contact.methods.kicker':'Contact methods',
      'contact.methods.text':'This page centralizes the company',
      'contact.methods.title':'All key communication channels in one place.',
      'contact.privacy':'By submitting you agree that the company may use your information to respond to your request.',
      'contact.social.future.fb_page_title':'Facebook company page',
      'contact.social.future.fb_profile_title':'Facebook profile',
      'contact.social.future.ig_title':'Instagram',
      'contact.social.future.pending':'Link to be added',
      'contact.social.future.title':'Reserved for future channels',
      'contact.social.kicker':'Social channels',
      'contact.social.linkedin.company':'Official company page',
      'contact.social.linkedin.profile':'Direct communication with the company / team',
      'contact.social.linkedin.title':'LinkedIn',
      'contact.social.text':'These social channels serve as additional contact points for networking, company presence and direct communication with the team.',
      'contact.social.title':'Corporate presence and direct messaging channels.',
      'contact.title':'Contact',
      'contact.toast':'Thank you! We will contact you shortly.',
'contact.newsletter.kicker':'Newsletter & updates',
'contact.newsletter.title':'Do you want steady updates from the company and the industry?',
'contact.newsletter.text':'Our newsletter is a separate communication channel with company updates, technical insights, selected maritime RSS updates and a shared content base for the future mobile app and browser extension.',
'contact.newsletter.cta1':'Open newsletter hub',
'contact.newsletter.cta2':'Open shared JSON feed',
'contact.newsletter.cta3':'Connect it with services and quotation flow',
      'footer.note':'Piraeus, Greece • Marine Repairs • 24/7 response on request',
      'home.audience.card1.text':'Support for ro/ro vessels, tankers, cargo ships, ferries and cruise ships, with emphasis on speed, safety and operational continuity.',
      'home.audience.card1.title':'Commercial & Passenger Shipping',
      'home.audience.card2.text':'Capability to support government, public, specialized or high-demand projects through a professional technical approach and structured communication.',
      'home.audience.card2.title':'Government & Specialized Projects',
      'home.audience.card3.text':'Technical support and selected works for private vessels whenever serious diagnosis, restoration and responsible repair management are required.',
      'home.audience.card3.title':'Private Vessel Support',
      'home.audience.kicker':'Who we serve',
      'home.audience.text':'Our first priority is commercial and passenger shipping, followed by government and specialized projects, while we also support private vessels whenever reliable technical intervention is required.',
      'home.audience.title':'Structured for demanding operators and technical teams.',
      'home.contact.kicker':'Άμεση επικοινωνία',
      'home.contact.note':'Piraeus, Greece • WhatsApp / Viber available • 24/7 upon request',
      'home.contact.text':'Επικοινωνήστε απευθείας με την Olympia Marine Repairs Ltd για technical coordination, quotation requests και διαθεσιμότητα emergency response. WhatsApp και Viber υποστηρίζονται και στους δύο αριθμούς.',
      'home.contact.title':'Χρειάζεστε άμεση τεχνική υποστήριξη ή προσφορά για επόμενο project;',
      'home.hero.badge1':'24/7 Support',
      'home.hero.badge2':'Voyage Repairs',
      'home.hero.badge3':'Drydock Support',
      'home.hero.badge4':'Riding Squads',
      'home.hero.badge5':'Worldwide Attendance on Request',
      'home.hero.cta_primary':'Request a quote',
      'home.hero.cta_secondary':'Services',
      'home.hero.eyebrow':'Marine repair coordination based in Piraeus',
      'home.hero.subtitle':'Olympia Marine Repairs Ltd provides voyage repairs, drydock support, troubleshooting, riding squads and 24/7 technical support, with rapid mobilization upon direct communication from Piraeus.',
      'home.hero.summary':'Ship repairs and technical support for commercial, passenger and specialized vessels.',
      'home.hero.title':'Marine repairs and technical support for commercial, passenger and specialized vessels.',
      'home.services.card1.li1':'Μηχανοστάσιο και all auxiliaries machineries',
      'home.services.card1.li2':'Έλεγχος κύριας μηχανής',
      'home.services.card1.li3':'Ηλεκτροστάσιο και βοηθητικά μηχανήματα',
      'home.services.card1.li4':'Έλεγχος πρόωσης, αξόνων και CPP',
      'home.services.card1.title':'Voyage Repairs',
      'home.services.card2.li1':'Ηλεκτρολογικές εργασίες',
      'home.services.card2.li2':'PLC και automation systems',
      'home.services.card2.li3':'Troubleshooting και system checks',
      'home.services.card2.li4':'Υποστήριξη λειτουργικών ελέγχων',
      'home.services.card2.title':'Electrical, PLC & Automation',
      'home.services.card3.li1':'Paints και coatings',
      'home.services.card3.li2':'Scrubber units',
      'home.services.card3.li3':'Cargo holds και hatch covers',
      'home.services.card3.li4':'Cargo gears, stabilizers και machinery',
      'home.services.card3.title':'Drydock Works',
      'home.services.card4.li1':'Διάγνωση βλαβών',
      'home.services.card4.li2':'Ρεκτιφιέ και επισκευές κυλίνδρων',
      'home.services.card4.li3':'Συστήματα καυσίμου και αντλίες',
      'home.services.card4.li4':'Turbochargers και quality control',
      'home.services.card4.title':'Diagnostics & Overhauls',
      'home.services.card5.li1':'Daily progress reporting',
      'home.services.card5.li2':'Φωτογραφίες πριν και μετά την εργασία',
      'home.services.card5.li3':'Μετρήσεις και τεχνικά σχόλια',
      'home.services.card5.li4':'Προτάσεις βελτίωσης όπου απαιτείται',
      'home.services.card5.title':'Documentation & Reporting',
      'home.services.card6.li1':'Άμεση κινητοποίηση',
      'home.services.card6.li2':'24/7 support',
      'home.services.card6.li3':'Class-related work support',
      'home.services.card6.li4':'Riding squads και worldwide attendance on request',
      'home.services.card6.title':'Emergency Response',
      'home.services.kicker':'Core services',
      'home.services.title':'Core areas of technical support and repair.',
      'home.standards.kicker':'Standards & confidence',
      'home.standards.text':'Olympia Marine Repairs Ltd supports marine repair projects with structured documentation, quality-focused procedures and work aligned with international maritime practices, shipyard requirements and class-related expectations.',
      'home.standards.title':'Work delivered with professional structure and international orientation.',
      'home.trust.1':'Piraeus-based coordination',
      'home.trust.2':'Commercial and passenger vessel support',
      'home.trust.3':'Government and specialized project capability',
      'home.trust.4':'Immediate mobilization on request',
      'home.why.kicker':'Why us',
      'home.why.li1':'Fast response from Piraeus',
      'home.why.li2':'Flexibility for voyage repairs and drydock support',
      'home.why.li3':'Direct communication with decision-makers',
      'home.why.li4':'Structured technical reporting and work tracking',
      'home.why.li5':'Support capability for urgent and demanding projects',
      'home.why.li6':'Professional international working mindset',
      'home.why.title':'Why work with us.',
'home.newsletter.kicker':'Newsletter',
'home.newsletter.title':'Get curated technical updates from Olympia Marine Repairs Ltd',
'home.newsletter.text':'We created a bilingual maritime newsletter for operators, technical managers, superintendents, decision-makers and private clients who want useful technical updates, company news and selected industry radar.',
'home.newsletter.cta':'Join the newsletter',
'home.newsletter.cta2':'Direct contact',
'home.newsletter.point1':'Bilingual content EL / EN',
'home.newsletter.point2':'RSS + manual company content',
'home.newsletter.point3':'Shared feed for website, app and extension',
      'meta.title_about':'Olympia Marine Repairs Ltd | About Us',
      'meta.title_contact':'Olympia Marine Repairs Ltd | Contact',
      'meta.title_home':'Olympia Marine Repairs Ltd | Marine Repairs in Piraeus',
      'meta.title_services':'Olympia Marine Repairs Ltd | Services',
'meta.title_newsletter':'Olympia Marine Repairs Ltd | Newsletter',
      'nav.about':'About',
      'nav.contact':'Contact',
      'nav.home':'Home',
     'nav.newsletter':'Newsletter', 'nav.services':'Services',
      'services.card1.label':'01',
      'services.card1.li1':'Main & auxiliary engines: technical checks, diagnosis and repairs',
      'services.card1.li2':'Engine room & power plant: auxiliaries and power generation systems',
      'services.card1.li3':'Propulsion systems: shafts, CPP and related functional checks',
      'services.card1.li4':'Electrical & automation: PLC, ship automation and onboard electrical networks',
      'services.card1.text':'Specialized onboard interventions and mobile technical attendance designed to protect vessel continuity and reduce unnecessary delays.',
      'services.card1.title':'Voyage Repairs & Mobile Technical Teams',
      'services.card2.label':'02',
      'services.card2.li1':'Hull & cargo spaces: cleaning, coatings and cargo hold support',
      'services.card2.li2':'Deck & cargo equipment: hatch covers, cargo gears, stabilizers and deck machinery',
      'services.card2.li3':'Environmental retrofit support: scrubber-related and associated technical works',
      'services.card2.li4':'Specialized machining: cylinders, fuel systems, pumps and turbochargers',
      'services.card2.text':'Integrated support during drydocking with emphasis on organized execution, technical supervision and the fastest practical return of the vessel to service.',
      'services.card2.title':'Drydocking & Shipyard Support',
      'services.card3.label':'03',
      'services.card3.li1':'Work aligned with IMO principles and class-related requirements',
      'services.card3.li2':'Support for inspections, technical attendance and project follow-up',
      'services.card3.li3':'Pre-purchase and new building technical support where requested',
      'services.card3.li4':'Quality control mindset with documented execution and traceability',
      'services.card3.text':'Support for projects requiring structured preparation, technical review, quality monitoring and alignment with international maritime requirements.',
      'services.card3.title':'Compliance, Inspections & Quality Control',
      'services.card4.label':'04',
      'services.card4.li1':'Daily progress reports with before/after photos',
      'services.card4.li2':'Measurements, technical comments and improvement recommendations',
      'services.card4.li3':'Project coordination with clear status and deliverable updates',
      'services.card4.li4':'Scalable support for larger project scopes upon coordination',
      'services.card4.text':'Transparency, office visibility and organized project follow-up from initial mobilization through final functional reporting.',
      'services.card4.title':'Technical Documentation & Project Management',
      'services.commercial.kicker':'Commercial transparency',
      'services.commercial.p1':'The commercial process is organized through quotation, scope confirmation and execution agreement. Advance terms, mobilization costs and special requirements are defined according to project type and operating environment.',
      'services.commercial.p2':'For high-pressure or complex projects, we prefer direct meetings or immediate coordination calls to reduce ambiguity and establish the right execution path from the beginning.',
      'services.commercial.title':'Clear commercial alignment before execution.',
      'services.core.kicker':'Core service areas',
      'services.core.text':'This page outlines how we organize technical works, drydock support, compliance coordination and reporting for operators who require visibility, safety and reliable execution.',
      'services.core.title':'Four main service pillars.',
      'services.cta.kicker':'Next step',
      'services.cta.note':'WhatsApp / Viber available on both numbers • Coordination from Piraeus',
      'services.cta.text':'Contact Olympia Marine Repairs Ltd to organize scope review, technical coordination, mobilization planning and quotation according to your project.',
      'services.cta.title':'Need voyage attendance, drydock support or a technical quotation?',
      'services.hero.kicker':'Our Services',
      'services.lead':'Olympia Marine Repairs Ltd supports voyage repairs, drydock projects, compliance-driven interventions and technical documentation with structured communication, safety procedures and mobilization capability upon coordination.',
      'services.ops.kicker':'Mobilization & SLA logic',
      'services.ops.p1':'For projects requiring travel, attendance or an organized riding team, mobilization planning generally starts at least 5 working days before departure, following scope confirmation, access review, material readiness and operational constraints alignment.',
      'services.ops.p2':'During execution we provide daily reports and, at project close-out, a final functional status report. Where required, validation and signatures can be coordinated with the relevant vessel and office representatives.',
      'services.ops.title':'How mobilization and execution are organized.',
      'services.qhse.card1.text':'We apply a permit-to-work logic for hot works, enclosed spaces and other demanding interventions in coordination with the captain, chief officer, chief engineer and the relevant ship personnel.',
      'services.qhse.card1.title':'Permit-to-Work discipline',
      'services.qhse.card2.text':'Every job is carried out with the required protective measures, appropriate equipment and discipline in toolbox talks, isolation procedures and LOTO whenever applicable.',
      'services.qhse.card2.title':'Safety barriers on site',
      'services.qhse.card3.text':'Proper timing and outcomes depend on suitable access conditions, equipment, supply support and operational coordination onboard or in the shipyard.',
      'services.qhse.card3.title':'Execution conditions',
      'services.qhse.kicker':'QHSE & safe execution',
      'services.qhse.text':'Execution is organized according to actual vessel conditions, communication with the crew and appropriate risk-control procedures.',
      'services.qhse.title':'Work safety and permit-to-work approach.',
      'services.scale.card1.meta':'Core response',
      'services.scale.card1.text':'The project core is staffed by key technical leaders and crew who can organize diagnosis, attendance and execution planning with a clear chain of responsibility.',
      'services.scale.card1.title':'Lean coordination team',
      'services.scale.card2.meta':'Extended capacity',
      'services.scale.card2.text':'Additional technicians can be integrated upon coordination depending on scope, shipyard environment, deadline pressure and access or specialty requirements.',
      'services.scale.card2.title':'Additional manpower upon agreement',
      'services.scale.card3.meta':'Large-scale projects',
      'services.scale.card3.text':'For industrial-scale projects, broader mobilization can be organized through project-based coordination and technical partnerships, with staffing adjusted to the size and nature of the assignment.',
      'services.scale.card3.title':'Scalable industrial support',
      'services.scale.kicker':'Availability & scalability',
      'services.scale.text':'The operating core functions as a 7-person team, with the ability to expand technical manpower according to workload, vessel location and the nature of the required works.',
      'services.scale.title':'Core team, extended network and project scaling.',
      'services.title':'Services focused on vessel operational continuity.',
      'services.trust.1':'Voyage repairs & mobile teams',
      'services.trust.2':'Drydock & shipyard support',
      'services.trust.3':'QHSE-focused execution',
      'services.trust.4':'Daily reporting & project visibility',
      'site.tagline':'Our expertise. Your safety in every ocean.',
      'tagline':'Our expertise. Your safety in every ocean.',

'meta.title_newsletter':'Olympia Marine Repairs Ltd | Newsletter',
'nav.newsletter':'Newsletter',

'newsletter.hero.kicker':'Olympia Marine Briefing',
'newsletter.hero.title':'Stay informed about everything concerning developments in shipping and the latest news from our team.',
'newsletter.hero.text':'The best way to stay in touch with us and learn each month about the most important developments.',

'newsletter.list.1':'Reliable updates on developments in shipping',
'newsletter.list.2':'Updates on company news and developments',
'newsletter.list.3':'Updates on the ship repair sector',
'newsletter.list.4':'Global and local developments',

'newsletter.rss.kicker':'Maritime RSS Feed',
'newsletter.rss.title':'Maritime RSS Feed',
'newsletter.rss.text':'Selected news and developments from the international shipping industry appear automatically below.',

'newsletter.form.kicker':'Subscribe',
'newsletter.form.title':'Join today',
'newsletter.form.text':'Stay informed and stay connected with us by entering your email below.',
'newsletter.form.email':'Email',
'newsletter.form.email_ph':'name@company.com',
'newsletter.form.submit':'Subscribe',

'newsletter.app.kicker':'Mobile app',
'newsletter.app.title':'Olympia Marine Repairs App in Android App Store',
'newsletter.app.note':'olympia marine repairs app'    }
  },

  captureDefaults(){
    const titleEl = document.querySelector('title[data-i18n]');
    if (titleEl) this.defaultsText[titleEl.getAttribute('data-i18n')] = titleEl.textContent;
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (!(key in this.defaultsText)) this.defaultsText[key] = el.textContent;
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (!(key in this.defaultsPlaceholder)) this.defaultsPlaceholder[key] = el.getAttribute('placeholder') || '';
    });
  },

  t(key){
  return this.dict[this.current]?.[key]
    || this.defaultsText[key]
    || this.dict.en?.[key]
    || key;
},

tp(key){
  return this.dict[this.current]?.[key]
    || this.defaultsPlaceholder[key]
    || this.dict.en?.[key]
    || key;
},
  set(lang){
    this.current = lang;
    localStorage.setItem('lang', lang);
    document.documentElement.lang = lang;

    document.querySelectorAll('[data-i18n]').forEach(el => {
      el.textContent = this.t(el.getAttribute('data-i18n'));
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      el.setAttribute('placeholder', this.tp(el.getAttribute('data-i18n-placeholder')));
    });

    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === lang);
    });

    const titleEl = document.querySelector('title[data-i18n]');
    if (titleEl) titleEl.textContent = this.t(titleEl.getAttribute('data-i18n'));

    const languageField = document.querySelector('input[name="_language"]');
    if (languageField) languageField.value = lang;
  },

  init(){
    this.captureDefaults();
    const saved = localStorage.getItem('lang');
    const prefer = saved || (navigator.language?.startsWith('el') ? 'el' : 'en');
    this.set(prefer);

    const here = location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.menu a').forEach(a => {
      if (a.getAttribute('href') === here) a.classList.add('active');
    });

    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => this.set(btn.dataset.lang));
    });
  }
};

document.addEventListener('DOMContentLoaded', () => i18n.init());
